# UMD_package
post-processing package that performs analysis of structural, transport, and thermodynamic properties from ab initio molecular dynamics simulations
